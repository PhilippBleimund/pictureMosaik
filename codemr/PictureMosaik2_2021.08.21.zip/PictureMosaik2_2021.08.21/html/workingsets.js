var EQ_workingSetList = [
{name: 'PictureMosaik2', path:'picturemosaik2'}
];
