var matrix = [[0,0,4,0,1],[4,0,2,0,0],[0,0,0,0,0],[1,1,1,0,0],[0,1,0,1,0]]
var packages = [{
"name": " PictureAnalyse", "color": " #3182bd"
}
,{
"name": " Computation", "color": " #6baed6"
}
,{
"name": " saveObjects", "color": " #9ecae1"
}
,{
"name": " GUI", "color": " #c6dbef"
}
,{
"name": " ImageViewer", "color": " #e6550d"
}
];
